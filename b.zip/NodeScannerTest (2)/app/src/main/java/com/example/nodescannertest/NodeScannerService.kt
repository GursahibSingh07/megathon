package com.example.nodescannertest // Make sure this matches your package

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// NOTE: needs minSdk 26 (hintText / isShowingHintText)
class NodeScannerService : AccessibilityService() {

    // ==========================================
    // CONFIG
    // ==========================================

    // Set to true to log the node structure around these texts (for debugging)
    private val DEBUG_DUMP = false
    private val DEBUG_DUMP_TEXTS = setOf("True", "False", "10 points")

    // The actions file, inside the app's private files dir:
    //   /data/data/com.example.nodescannertest/files/form_actions.json
    // After it has been run it is renamed to form_actions.done.json so it never runs twice.
    private val ACTIONS_FILE = "form_actions.json"
    private val DONE_FILE = "form_actions.done.json"

    // Pause between actions so the web page can react (raise if fields get skipped)
    private val STEP_DELAY_MS = 500L

    private val TAG = "AutoFill"

    // ==========================================
    // STATE
    // ==========================================

    // Chronological text of the screen for the LLM
    private val screenTextLayout = mutableListOf<String>()

    // Actual UI nodes so we can click / type into them later
    private val actionableNodes = mutableMapOf<Int, AccessibilityNodeInfo>()

    // What kind of node each ID is, so "type" can't hit a button and "click" can't hit an input
    private val nodeKinds = mutableMapOf<Int, NodeKind>()

    // Remembers placeholder text of input fields, so it survives after the user starts typing
    private val hintCache = mutableMapOf<String, String>()

    // Nodes already used as part of an option (a radio, or the text label next to it)
    private val consumed = mutableSetOf<AccessibilityNodeInfo>()

    private var nodeIdCounter = 0

    // Most recent plain text seen during traversal (fallback hint for web inputs)
    private var lastTextSeen: String? = null

    // Autofill state
    private val handler = Handler(Looper.getMainLooper())
    private var isFilling = false
    private var lastSkipReason = ""

    private enum class NodeKind { INPUT, OPTION }

    private data class UiAction(val action: String, val targetId: Int, val value: String?)

    // Chrome/WebView exposes the HTML/ARIA role in the node extras under this key
    private val CHROME_ROLE_KEY = "AccessibilityNodeInfo.chromeRole"

    private val CHOICE_ROLES = setOf(
        "radiobutton", "radio", "checkbox", "switch",
        "menuitemradio", "menuitemcheckbox", "listboxoption", "togglebutton"
    )
    private val INTERACTIVE_ROLES = CHOICE_ROLES + setOf(
        "button", "link", "menuitem", "tab", "popupbutton", "combobox", "combobox_select"
    )

    override fun onServiceConnected() {
        Log.d(TAG, "Service connected. Waiting for ${File(filesDir, ACTIONS_FILE).absolutePath}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // While we are filling, our own clicks/typing fire events. Rescanning then would
        // renumber the IDs in the middle of the run, so ignore events until we're done.
        if (isFilling) return

        val type = event.eventType
        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            // New screen -> forget old hints. (Not on content change, or hints vanish while typing)
            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                hintCache.clear()
            }

            val rootNode = rootInActiveWindow ?: return

            // Reset memory for the new screen state
            screenTextLayout.clear()
            actionableNodes.clear()
            nodeKinds.clear()
            consumed.clear()
            nodeIdCounter = 0
            lastTextSeen = null

            try {
                traverseTree(rootNode)
            } catch (e: Exception) {
                // The page can change mid-scan; log it and skip this frame instead of crashing
                Log.e("NodeScanner", "Traversal failed, skipping this screen update", e)
                return
            }

            if (screenTextLayout.isNotEmpty()) {
                val promptContext = screenTextLayout.joinToString("\n")
                Log.d("LlamaContext", "\n--- SCREEN LAYOUT ---\n$promptContext\n---------------------")
            }

            // Now that IDs exist for this screen, run the JSON if it fits this screen
            maybeRunActions()
        }
    }

    // ==========================================
    // AUTOFILL FROM JSON
    // ==========================================

    private fun maybeRunActions() {
        val file = File(filesDir, ACTIONS_FILE)
        if (!file.exists()) return

        val actions = try {
            parseActions(file.readText())
        } catch (e: Exception) {
            logSkipOnce("Could not parse $ACTIONS_FILE: ${e.message}")
            return
        }
        if (actions.isEmpty()) {
            logSkipOnce("$ACTIONS_FILE has no actions")
            return
        }

        // Check EVERY action against the current screen before doing anything.
        // If the form isn't the screen in front of us (e.g. home screen, where ID 9 is "More"),
        // the IDs won't line up and we do nothing.
        val problems = actions.mapNotNull { a ->
            val kind = nodeKinds[a.targetId]
            when {
                a.action != "type" && a.action != "click" -> "unknown action '${a.action}'"
                kind == null -> "ID ${a.targetId} is not on this screen"
                a.action == "type" && kind != NodeKind.INPUT -> "ID ${a.targetId} is not an input field"
                a.action == "click" && kind != NodeKind.OPTION -> "ID ${a.targetId} is not a selectable option"
                else -> null
            }
        }
        if (problems.isNotEmpty()) {
            logSkipOnce("Not filling, this screen doesn't match the JSON: ${problems.joinToString("; ")}")
            return
        }

        // Snapshot the nodes now; IDs can change once we start clicking
        val plan = actions.map { it to actionableNodes.getValue(it.targetId) }

        // Mark the file as used BEFORE running, so a crash/restart can't run it twice
        // (running twice would un-tick checkboxes)
        file.renameTo(File(filesDir, DONE_FILE))

        Log.d(TAG, "Screen matches JSON, running ${plan.size} action(s)")
        lastSkipReason = ""
        isFilling = true
        runStep(plan, 0)
    }

    private fun runStep(plan: List<Pair<UiAction, AccessibilityNodeInfo>>, index: Int) {
        if (index >= plan.size) {
            isFilling = false
            Log.d(TAG, "Autofill finished (${plan.size} action(s))")
            return
        }

        val (action, node) = plan[index]
        try {
            node.refresh()
            // Scroll the field into view first (helps for fields further down the form)
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN.id)

            when (action.action) {
                "type" -> {
                    val ok = typeInto(node, action.value ?: "")
                    Log.d(TAG, "Step ${index + 1}: typed into ID ${action.targetId} (success=$ok)")
                }
                "click" -> {
                    if (node.isChecked) {
                        // Clicking a ticked checkbox would UN-tick it
                        Log.d(TAG, "Step ${index + 1}: ID ${action.targetId} already selected, skipping")
                    } else {
                        clickNode(node)
                        Log.d(TAG, "Step ${index + 1}: clicked ID ${action.targetId}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Step ${index + 1} (ID ${action.targetId}) failed", e)
        }

        handler.postDelayed({ runStep(plan, index + 1) }, STEP_DELAY_MS)
    }

    // Accepts either a top-level array, or {"actions": [...]}
    private fun parseActions(text: String): List<UiAction> {
        val trimmed = text.trim()
        val array = if (trimmed.startsWith("[")) JSONArray(trimmed)
        else JSONObject(trimmed).optJSONArray("actions") ?: JSONArray()

        val result = mutableListOf<UiAction>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val id = when {
                item.has("target_id") -> item.optInt("target_id", -1)
                item.has("id") -> item.optInt("id", -1)
                else -> -1
            }
            if (id < 0) continue
            result.add(
                UiAction(
                    action = item.optString("action").trim().lowercase(),
                    targetId = id,
                    value = if (item.has("value")) item.optString("value") else null
                )
            )
        }
        return result
    }

    private fun logSkipOnce(reason: String) {
        if (reason == lastSkipReason) return
        lastSkipReason = reason
        Log.d(TAG, reason)
    }

    // ==========================================
    // CLASSIFICATION HELPERS
    // ==========================================

    private fun cleanTextOf(n: AccessibilityNodeInfo?): String? {
        if (n == null) return null
        val raw = n.text?.toString() ?: n.contentDescription?.toString() ?: return null
        val c = raw.replace(Regex("[^a-zA-Z0-9 ?]"), "").trim()
        return if (c.length > 1) c else null
    }

    private fun chromeRole(n: AccessibilityNodeInfo): String =
        n.extras?.getString(CHROME_ROLE_KEY)?.lowercase() ?: ""

    // Radio / checkbox / switch, native or web
    private fun isChoiceControl(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        if (n.isCheckable) return true
        val cls = n.className?.toString() ?: ""
        if (cls.contains("RadioButton") || cls.contains("CheckBox") || cls.contains("Switch")) return true
        return chromeRole(n) in CHOICE_ROLES
    }

    // Something the user can actually press
    private fun isActionable(n: AccessibilityNodeInfo?): Boolean {
        if (n == null) return false
        if (isChoiceControl(n)) return true

        val role = chromeRole(n)
        if (role in INTERACTIVE_ROLES) return true

        val cls = n.className?.toString() ?: ""
        if (cls.contains("Button")) return true

        val hasClickAction = n.isClickable ||
                n.actionList.any { it.id == AccessibilityNodeInfo.ACTION_CLICK }
        if (!hasClickAction) return false

        // Native views: trust the click flag. Web nodes with a generic role: don't.
        return role.isEmpty()
    }

    private fun countChoiceControls(n: AccessibilityNodeInfo?, stopAt: Int = 2, depth: Int = 0): Int {
        if (n == null || depth > 10) return 0
        var c = if (isChoiceControl(n)) 1 else 0
        for (i in 0 until n.childCount) {
            if (c >= stopAt) break
            c += countChoiceControls(childAt(n, i), stopAt, depth + 1)
        }
        return c
    }

    private fun findFirstChoiceControl(n: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 10) return null
        if (isChoiceControl(n)) return n
        for (i in 0 until n.childCount) {
            findFirstChoiceControl(childAt(n, i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun textsIn(
        n: AccessibilityNodeInfo?,
        out: MutableSet<String>,
        limit: Int,
        depth: Int = 0
    ) {
        if (n == null || depth > 10 || out.size >= limit) return
        cleanTextOf(n)?.let { out.add(it) }
        for (i in 0 until n.childCount) {
            textsIn(childAt(n, i), out, limit, depth + 1)
        }
    }

    private fun firstTextIn(n: AccessibilityNodeInfo?): String? {
        val s = linkedSetOf<String>()
        textsIn(n, s, 1)
        return s.firstOrNull()
    }

    // getChild() throws (instead of returning null) when the index is out of range
    private fun childAt(parent: AccessibilityNodeInfo, i: Int): AccessibilityNodeInfo? {
        if (i < 0 || i >= parent.childCount) return null
        return try {
            parent.getChild(i)
        } catch (e: IndexOutOfBoundsException) {
            null
        }
    }

    private fun indexInParent(parent: AccessibilityNodeInfo, child: AccessibilityNodeInfo): Int {
        for (i in 0 until parent.childCount) if (childAt(parent, i) == child) return i
        return -1
    }

    // ==========================================
    // TRAVERSAL
    // ==========================================

    private fun traverseTree(node: AccessibilityNodeInfo?) {
        if (node == null) return
        if (node in consumed) return   // already listed as part of an option

        val cleanText = cleanTextOf(node)

        if (DEBUG_DUMP && cleanText in DEBUG_DUMP_TEXTS) dumpAround(node)

        // 1. Input field
        if (node.isEditable || node.className?.contains("EditText") == true) {
            val id = nodeIdCounter++
            actionableNodes[id] = node
            nodeKinds[id] = NodeKind.INPUT

            val key = node.viewIdResourceName ?: node.hashCode().toString()

            val hint = node.hintText?.toString()
                ?: if (node.isShowingHintText) node.text?.toString() else null
            if (!hint.isNullOrBlank()) hintCache[key] = hint

            val currentValue = if (node.isShowingHintText) "" else node.text?.toString() ?: ""

            val label = hintCache[key]
                ?: node.contentDescription?.toString()
                ?: lastTextSeen
                ?: ""

            screenTextLayout.add("[ID: $id] INPUT_FIELD hint=\"$label\" current=\"$currentValue\"")
        }
        // 2. Radio / checkbox / switch itself: list it with the text that belongs to it
        else if (isChoiceControl(node)) {
            val label = cleanText
                ?: firstTextIn(node)
                ?: findLabelFor(node)?.let { (labelNode, text) ->
                    consumed.add(labelNode)
                    text
                }
                ?: "(unlabeled)"

            addOption(node, label)
            lastTextSeen = label
            return   // its children are part of the control
        }
        // 3. Plain text: is it a button, or the label of a nearby radio?
        else if (cleanText != null) {
            val target = when {
                isActionable(node) -> node
                else -> findChoiceControlNear(node)?.also { consumed.add(it) }
                    ?: findOwningClickableAncestor(node)
            }

            if (target != null) {
                addOption(target, cleanText)
            } else if (cleanText.length > 2) {
                screenTextLayout.add("LABEL: $cleanText")
            }

            lastTextSeen = cleanText
        }

        for (i in 0 until node.childCount) {
            traverseTree(childAt(node, i))
        }
    }

    // Returns false if this target was already listed (avoids duplicates)
    private fun addOption(target: AccessibilityNodeInfo, label: String): Boolean {
        if (actionableNodes.containsValue(target)) return false
        val id = nodeIdCounter++
        actionableNodes[id] = target
        nodeKinds[id] = NodeKind.OPTION
        val state = if (target.isChecked) " (SELECTED)" else ""
        screenTextLayout.add("[ID: $id] SELECTABLE_OPTION: $label$state")
        return true
    }

    private fun findLabelFor(control: AccessibilityNodeInfo): Pair<AccessibilityNodeInfo, String>? {
        var child = control
        var depth = 0
        while (depth < 3) {
            val parent = child.parent ?: return null

            if (countChoiceControls(parent) > 1) {
                // Reached the option group. Flat layout: [radio, text, radio, text]
                val idx = indexInParent(parent, child)
                val next = childAt(parent, idx + 1)
                if (next != null && countChoiceControls(next, 1) == 0) {
                    firstTextIn(next)?.let { return next to it }
                }
                return null
            }

            for (i in 0 until parent.childCount) {
                val sib = childAt(parent, i) ?: continue
                if (sib == child) continue
                val t = firstTextIn(sib) ?: continue
                return sib to t
            }

            child = parent
            depth++
        }
        return null
    }

    private fun findChoiceControlNear(textNode: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var child = textNode
        var depth = 0
        while (depth < 3) {
            val parent = child.parent ?: return null
            when (countChoiceControls(parent)) {
                1 -> return findFirstChoiceControl(parent)
                0 -> { /* keep climbing */ }
                else -> {
                    // Flat layout with text before its control: [text, radio, text, radio]
                    val idx = indexInParent(parent, child)
                    val next = childAt(parent, idx + 1)
                    return if (isChoiceControl(next)) next else null
                }
            }
            child = parent
            depth++
        }
        return null
    }

    // A clickable ancestor only counts if this text is the ONLY text inside it
    private fun findOwningClickableAncestor(
        textNode: AccessibilityNodeInfo,
        maxDepth: Int = 3
    ): AccessibilityNodeInfo? {
        var p = textNode.parent
        var depth = 0
        while (p != null && depth < maxDepth) {
            val texts = linkedSetOf<String>()
            textsIn(p, texts, limit = 2)
            if (texts.size > 1) return null
            if (isActionable(p)) return p
            p = p.parent
            depth++
        }
        return null
    }

    // Debug helper: prints the node, its ancestors and their siblings
    private fun dumpAround(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        var d = 0
        while (n != null && d < 4) {
            Log.d(
                "NodeDump",
                "L$d cls=${n.className} role=${chromeRole(n)} text=${n.text} desc=${n.contentDescription} " +
                        "click=${n.isClickable} check=${n.isCheckable} checked=${n.isChecked} " +
                        "actions=${n.actionList.map { it.id }} children=${n.childCount}"
            )
            val p = n.parent
            if (p != null) {
                for (i in 0 until p.childCount) {
                    val s = childAt(p, i) ?: continue
                    Log.d(
                        "NodeDump",
                        "   sibling cls=${s.className} role=${chromeRole(s)} text=${s.text} " +
                                "desc=${s.contentDescription} click=${s.isClickable} " +
                                "check=${s.isCheckable} actions=${s.actionList.map { it.id }} " +
                                "children=${s.childCount}"
                    )
                }
            }
            n = p
            d++
        }
    }

    override fun onInterrupt() {
        Log.d("NodeScanner", "Service Interrupted")
    }

    // ==========================================
    // LOW-LEVEL ACTIONS
    // ==========================================

    // Public, ID-based versions (still usable from elsewhere)
    fun executeClick(targetId: Int) {
        val node = actionableNodes[targetId]
        if (node == null) {
            Log.e(TAG, "Failed to click node ID: $targetId. Node not found.")
            return
        }
        clickNode(node)
    }

    fun executeType(targetId: Int, textToInsert: String) {
        val node = actionableNodes[targetId]
        if (node == null) {
            Log.e(TAG, "Failed to type in node ID: $targetId. Node not found.")
            return
        }
        typeInto(node, textToInsert)
    }

    private fun clickNode(node: AccessibilityNodeInfo) {
        // 1. Try the node, then walk up parents until something accepts the click
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 5) {
            if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            n = n.parent
            depth++
        }

        // 2. Fallback: tap the center of the node on screen
        //    (needs android:canPerformGestures="true" in accessibility_service_config.xml)
        Log.w(TAG, "performAction click failed, trying coordinate tap")
        tapNodeCenter(node)
    }

    private fun typeInto(node: AccessibilityNodeInfo, text: String): Boolean {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        node.performAction(AccessibilityNodeInfo.ACTION_CLICK) // web inputs often need a tap to focus

        // 1. Normal way
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true

        // 2. Fallback: paste from the clipboard
        Log.w(TAG, "SET_TEXT failed, trying clipboard paste")
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("autofill", text))
        return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    private fun tapNodeCenter(node: AccessibilityNodeInfo) {
        val bounds = Rect()
        node.getBoundsInScreen(bounds)
        if (bounds.isEmpty) {
            Log.e(TAG, "Coordinate tap failed: node has empty bounds")
            return
        }

        val path = Path().apply { moveTo(bounds.exactCenterX(), bounds.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()

        val dispatched = dispatchGesture(gesture, null, null)
        if (!dispatched) Log.e(TAG, "dispatchGesture rejected (is canPerformGestures enabled?)")
    }
}