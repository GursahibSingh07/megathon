#pragma once

#define GGML_VERSION "0.26.0"
#define GGML_COMMIT  "0b48a4f"
